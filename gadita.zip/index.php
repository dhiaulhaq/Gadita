<?php

header('Location: public/');
