<h1>Create Product</h1>

<form action="/products" method="POST">
    <?php echo csrf_field(); ?>
    Name : <input type="text" name="name"><br>
    Description : <input type="text" name="description"><br>
    Price : <input type="number" name="price"><br>
    Image URL : <input type="text" name="image_url"><br>

    <input type="submit" value="Save">
</form><?php /**PATH D:\xampp\htdocs\onlineshop\resources\views/products/create.blade.php ENDPATH**/ ?>